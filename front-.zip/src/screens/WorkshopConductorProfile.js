import React from "react";
import WorkshopConductorSidebar from "../components/WorkshopConductorSidebar";

const WorkshopConductorProfile = () => {
  return (
    <div>
      <WorkshopConductorSidebar />  
  </div>
  );
};

export default WorkshopConductorProfile;
