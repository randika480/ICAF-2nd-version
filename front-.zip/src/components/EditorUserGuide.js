import React from "react";

const EditorUserGuide = () => {
  return <div></div>;
};

export default EditorUserGuide;
